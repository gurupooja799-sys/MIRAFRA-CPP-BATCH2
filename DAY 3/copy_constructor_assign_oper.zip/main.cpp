#include<iostream>
using namespace std;
class car{
    int fuel;
    int *vehiclenum;
    public:
    car(int f=0,int v=0):fuel(f),vehiclenum(new int(v))   
    {
        cout<<"constructor called\n";
    }
    car(const car& ob)
    {
        vehiclenum = new int(*ob.vehiclenum);
        fuel=ob.fuel;
        cout<<"copy constructor called\n";
    }
    car& operator=(const car& ob)
    {
        if(this!= &ob)
        {
            delete this->vehiclenum;
            this->fuel=ob.fuel;
            this->vehiclenum=new int(*ob.vehiclenum);
        }
        cout<<"copy assignment operator called\n";
        return *this;
    }
    void display()
    {
        cout<<"fuel="<<fuel<<"   "<<"vehiclenum="<<*vehiclenum<<endl;
    }
    ~car()
    {
        cout<<"destructor called\n";
        delete vehiclenum;
    }
};

int main()
{
    car c1(80,12345);
    car c2=c1;
    car c3;
    c3=c1;
    c1.display();
    c2.display();
    c3.display();
    return 0;
}







