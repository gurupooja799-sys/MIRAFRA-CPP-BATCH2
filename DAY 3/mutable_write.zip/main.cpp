#include<iostream>
#include<memory>
using namespace std;
class sensor
{
    int val;
    mutable int count;
    public:
    sensor(int v):val(v),count(0){}
    int read() const      //constant member function
    {
        count++;      //mutable variable
        return val;
    }
    int get_read_count() const
    {
        return count;
    }
    void write(int v)    //never take write function as constant
    {            //generally write is used to modify value,it should be nonconst
        val=v;
    }
};
int main()
{
    sensor s1(50);
    const sensor s2(60);
    cout<<"sensor1 val="<<s1.read()<<endl;
    s1.write(100);
    cout<<"sensor1 val="<<s1.read()<<endl;
    cout<<"count1="<<s1.get_read_count()<<endl;
    cout<<"sensor2 val="<<s2.read()<<endl;
    s2.write(120);        //we cannot call non const member function
    // const object is only possible to mutable,explicitly we're unable to change
    cout<<"sensor2 val="<<s2.read()<<endl;
    cout<<"count2="<<s2.get_read_count()<<endl;
    return 0;
}









