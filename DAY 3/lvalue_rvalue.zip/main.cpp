#include<iostream>
using namespace std;
int& fun(int &x)
{
    static int y=x+5;
    return y;
}
void print(int &t)
{
    cout<<"int &  "<<t<<"  addr="<<&t<<endl;
}
void print(int &&t)
{
    cout<<"int &&  "<<t<<"   addr="<<&t<<endl;
}
void print(const int& t)
{
    cout<<"const int&  "<<t<<"  addr="<<&t<<endl;
}
int main()
{
    int x=5;    //x is lvalue
    int &r1=x;  //reference storing lvalue
    const int &r2=20;
    int &r3=fun(x);
    int &&r4=100;
    print(x);
    print(r1);
    print(r2);
    print(r3);
    print(r4);
    print(8);
    return 0;
}