#include<iostream>
#include<memory>
using namespace std;
class sensor
{
    int val;
    mutable int count;
    public:
    sensor(int v):val(v),count(0){}
    int read() const      //constant member function
    {
        count++;      //mutable variable
        return val;
    }
    int get_read_count() const
    {
        return count;
    }
};
int main()
{
    sensor s1(50);
    const sensor s2(60);
    cout<<"sensor1 val="<<s1.read()<<endl;
    cout<<"sensor1 val="<<s1.read()<<endl;
    cout<<"count1="<<s1.get_read_count()<<endl;
    cout<<"sensor2 val="<<s2.read()<<endl;
    cout<<"sensor2 val="<<s2.read()<<endl;
    cout<<"count2="<<s2.get_read_count()<<endl;
    return 0;
}









