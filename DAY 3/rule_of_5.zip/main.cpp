#include<iostream>
using namespace std;
class car{
    int fuel;
    int *vehiclenum;
    public:
    car(int f=0,int v=0):fuel(f),vehiclenum(new int(v))   
    {
        cout<<"constructor called\n";
    }
    
    //copy constructor
     car( car& ob)
    {
        vehiclenum = new int(*ob.vehiclenum);
        fuel=ob.fuel;
        cout<<"copy constructor called\n";
    }
    
    //copy assignment operator
     car& operator=(const car& ob)
    {
        if(this!= &ob)
        {
            delete this->vehiclenum;
            this->fuel=ob.fuel;
            this->vehiclenum=new int(*ob.vehiclenum);
        }
        cout<<"copy assignment operator called\n";
        return *this;
    }
    
    //move constructor
    car( car&& ob)
    {
        vehiclenum = ob.vehiclenum;
        fuel=ob.fuel;
        ob.vehiclenum=nullptr;
        cout<<"move constructor called\n";
    }
    
    //move assignment operator
    car& operator=(car&& ob)
    {
        if(this!= &ob)
        {
            this->fuel=ob.fuel;
            this->vehiclenum=ob.vehiclenum;
            ob.vehiclenum=nullptr;
        }
        cout<<"move assignment operator called\n";
        return *this;
    }
    
    void display()
    {
        cout<<"fuel="<<fuel<<"   "<<"vehiclenum="<<*vehiclenum<<endl;
    }
    
    //destructor
    ~car()
    {
        cout<<"destructor called\n";
        delete vehiclenum;
    }
};

int main()
{
    car c1(80,12345);
    car c2=move(c1);
    car c3;
     c3=move(c2);
    car c4=c3;
    car c5;
    c5=c4;
    c5.display();
    c4.display();
    c3.display();
    c1.display();
    c2.display();
    return 0;
}







