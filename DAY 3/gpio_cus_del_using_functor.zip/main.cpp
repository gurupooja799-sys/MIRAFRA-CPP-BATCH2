#include<iostream>
#include<memory>
#include<algorithm>
using namespace std;
class gpio
{
    bool state;
    public:
    gpio(bool s=0)
    {
        state=s;
    }
    bool operator()(int s)
    {
        if(s==0)
        state=0;
        else
        state=1;
        return state;
    }
};
void fun(int r)
{
     if(r)
    cout<<"on state\n";
    else 
    cout<<"off state\n";
}
int main()
{
    gpio ob1;
    bool r=ob1(1);
    fun(r);
    r=ob1(0);
    fun(r);
    return 0;
}