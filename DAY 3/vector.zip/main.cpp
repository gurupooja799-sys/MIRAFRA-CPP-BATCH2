#include<iostream>
#include<vector>
using namespace std;
//Rule of 0
class car
{
    vector<int>vehiclenum;
    public:
    car(int count):vehiclenum(count,0){}
    void set_value(int index,int val)
    {
        if(index<vehiclenum.size())
        {
            vehiclenum[index]=val;
        }
    }
    void display()
    {
        int i=1;
        for(const auto& x:vehiclenum)
        {
            cout<<"car"<<i<<"="<<x<<endl;
            i++;
        }
        cout<<endl;
    }
    void sizes()
    {
        cout<<"size of garage="<<vehiclenum.size()<<endl;
    }
};
int main()
{
    car garage1(2);
    garage1.set_value(0,111);
    garage1.set_value(1,222);
    car garage2(3);
    garage2.set_value(0,333);
    garage2.set_value(1,444);
    garage2.set_value(2,55);
    cout<<"garage1\n";
    garage1.sizes();
    garage1.display();
    cout<<"garage2\n";
    garage2.sizes();
    garage2.display();
    car garage3=garage1;  //copy constructor will enable(deep)
    cout<<"garage3\n";
     garage3.sizes();
    garage3.display();
    car garage4(1);
    garage4=garage2;   //assignment operator
    cout<<"garage4\n";
    garage4.sizes();
    garage4.display();
    return 0;
}

//in copy constructor first it deletes previous memory and assign new memory 
//so no need to worry about memory size





