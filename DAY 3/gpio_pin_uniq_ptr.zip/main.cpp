#include<iostream>
#include<memory>
using namespace std;
class gpio
{
    int pin;
    public:
    gpio(int p=0)
    {
        pin=p;
    }
    
};
class gpio_deletor
{
    
}