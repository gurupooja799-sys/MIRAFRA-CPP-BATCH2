#include<iostream>
using namespace std;
class Clock
{
     public:
    bool clk;
    Clock(bool i=0):clk(i){}
};
class gpio
{
    int pin;
    Clock *cptr;
    public:
    gpio(int p=0,bool c=0):pin(p),cptr(new Clock(c))
    {
      cout<<"constructor called\n";
    }
    
    //copy constructor
    gpio(const gpio& ob)
    {
        pin=ob.pin;
        cptr=new Clock(*ob.cptr);
        cout<<"copy constructor called\n";
        delete ob.cptr;
    }
    
    //copy assignment operator
    gpio& operator=(const gpio& ob)
    {
        if(this!=&ob)
        {
            pin=ob.pin;
            cptr=new Clock(*ob.cptr);
            delete ob.cptr;
        }
        cout<<"copy assignment operator\n";
        return *this;
    }
    
    //move constructor
    gpio(gpio&& ob)
    {
        pin=ob.pin;
        cptr=ob.cptr;
        ob.cptr=nullptr;
        cout<<"move constructor\n";
    }
    
    //move assignment operator
    gpio& operator=(gpio&& ob)
    {
        if(this!=&ob)
        {
            pin=ob.pin;
            cptr=ob.cptr;
            ob.cptr=nullptr;
        }
        cout<<"move assignment operator\n";
        return *this;
    }
    
    void clock_status()
    {
        if(cptr->clk)
        cout<<"pin="<<pin<<"is in clock is in active mode\n";
        else
         cout<<"pin="<<pin<<"'s clock is in active mode\n";
    }
    ~gpio()
    {
        cout<<"destructor called\n";
        delete cptr;
    }
};
int main()
{
    gpio p1(13,1);
    p1.clock_status();
    gpio p2(15);
    gpio p3=p1; //copy constructor
    gpio p4;
    p4=p1;     //copy assignment
    gpio p5=move(p2);   //move cons
    gpio p6;
    gpio p7(7,1);
    p6=move(p7);   //move ass
    p3.clock_status();
    p4.clock_status();
    p5.clock_status();
    p6.clock_status();
    return 0;
}









