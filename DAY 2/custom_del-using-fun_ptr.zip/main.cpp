#include<iostream>
#include<memory>
#include<utility>
using namespace std;
template<typename T>
void Freedeleter(T* p)
{
    free(p);
    cout<<"memory deallocated using function pointer with custom deleter\n";
}
int main()
{
    unique_ptr<float,void(*)(float*)>p{(float*)malloc(sizeof(float)),Freedeleter};
    if(!p)
    {
        cout<<"memory not allocated\n";
        return 1;
    }
    *p=10.5;
    cout<<"p val="<<*p<<endl;
    return 0;
}