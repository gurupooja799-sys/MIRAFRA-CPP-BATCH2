#include<iostream>
#include<memory>
#include<utility>
using namespace std;
class Freedeleter
{
    public:
    void operator()(FILE *p) const
    {
        if(p)
        fclose(p);
        cout<<"file closed\n";
    }
};
int main()
{
    unique_ptr<FILE,Freedeleter>p(fopen("data.txt","w"));
    if(p)
    {
        cout<<"file open\n";
    }
    return 0;
}