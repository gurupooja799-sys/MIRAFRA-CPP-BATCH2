#include<iostream>
#include<memory>
using namespace std;
template<typename T>
class sensor
{
    int n;
    public:
    sensor(int i=0)
    {
        n=i;
        cout<<"sensor constructor\n";
    }
    ~sensor()
    {
        cout<<"sensor destructor\n";
    }
    
};
class my_cls
{
    public:
    my_cls()
    {
        cout<<"my_cls constructor called\n";
    }
    ~my_cls()
    {
        cout<<"my_cls destructor called\n";
    }
    void greet()
    {
        cout<<"hi im greet fun\n";
    }
};

void fun()
{
    unique_ptr<my_cls>p1=make_unique<my_cls>();
}

int main()
{
    fun();
}




