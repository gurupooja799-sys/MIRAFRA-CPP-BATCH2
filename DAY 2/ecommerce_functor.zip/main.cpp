#include<iostream>
#include<vector>
#include<algorithm>
using namespace std;
class ecommerce
{
    int dis;
    public:
    ecommerce(int x=0)
    {
        dis=x;
    }
    int operator()(int p) const
    {
        return p - (p * dis / 100);
    }
    
};
int main()
{
    vector<int>prices{100,200,300};
    vector<int>dsc_prices(prices.size());
    int dis;
    ecommerce ob(10);
    transform(prices.begin(),prices.end(),dsc_prices.begin(),ob);
    for(int& x:dsc_prices)
    cout<<x<<" ";
    return 0;
}