#include<iostream>
#include<memory>
#include<utility>
using namespace std;
struct Freedeleter
{
    void operator()(int *p)
    {
        free(p);
        cout<<"memory released by free\n";
    }
};
int main()
{
    unique_ptr<int,Freedeleter>p{(int*)malloc(sizeof(int))};
    if(!p)
    {
        cout<<"memory not allocated\n";
        return 1;
    }
    *p=10;
    cout<<"p val="<<*p<<endl;
    return 0;
}