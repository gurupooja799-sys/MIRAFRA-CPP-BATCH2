#include<iostream>
#include<memory>
#include<utility>
using namespace std;
struct Freedeleter
{
    template<typename T>
    void operator()(T *p)
    {
       delete []p;  //custom deleter mainly uses for array,normal delete only delete first element
        cout<<"memory released for an array\n";
    }
};
int main()
{
    unique_ptr<int[],Freedeleter>p(new int[10]);
    if(!p)
    {
        cout<<"memory not allocated\n";
        return 1;
    }
    //unique_ptr deletes only first location
    //for proper deletion we can use custom deleter
    
    return 0;
}