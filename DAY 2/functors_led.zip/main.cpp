#include<iostream>
using namespace std;
class LED
{
    bool status;
    public:
    LED(bool i=0)
    {
        status=i;
    }
    bool operator()(bool i)
    {
        if(!status)
        status=i;
        return status;
    }
    void display()
    {
        if(status)
        cout<<"led is in on state\n";
        else
        cout<<"led is in off state\n";
    }
};
void fun(bool r)
{
     if(r)
    cout<<"led is in on state\n";
    else
    cout<<"led is in off state\n";
}
int main()
{
    LED l1(0);
    bool r=l1(0);
    fun(r);
    r=l1(1);
    fun(r);
   
    return 0;
}






