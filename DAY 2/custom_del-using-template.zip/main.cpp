#include<iostream>
#include<memory>
#include<utility>
using namespace std;
template<typename T>
struct Freedeleter
{
    void operator()(T *p)
    {
        free(p);
        cout<<"memory released by free\n";
    }
};
int main()
{
    unique_ptr<float,Freedeleter<float>>p{(float*)malloc(sizeof(float))};
    if(!p)
    {
        cout<<"memory not allocated\n";
        return 1;
    }
    *p=10;
    cout<<"p val="<<*p<<endl;
    return 0;
}