#include<iostream>
using namespace std;
class LED
{
    bool status;
    bool swit;
    public:
    LED(bool i=0,bool j=0)
    {
        status=i;
        swit=j;
    }
    bool operator()(bool i,bool j)
    {
       if(status!=i && j&&i)
       {
           status=i;
           swit=j;
       }
       else if(swit!=j && status&&j)
       {
           swit=j;
       }
       else if(!swit )
       status=0;
       return status;
    }
    void display()
    {
        if(status)
        cout<<"led is in on state\n";
        else
        cout<<"led is in off state\n";
    }
};
void fun(bool r)
{
     if(r)
    cout<<"led is in on state\n";
    else
    cout<<"led is in off state\n";
}
int main()
{
    LED l1(0,0);
    bool r=l1(0,1);
    fun(r);
    r=l1(1,1);
    fun(r);
    r=l1(1,0);
    fun(r);
   
    return 0;
}






