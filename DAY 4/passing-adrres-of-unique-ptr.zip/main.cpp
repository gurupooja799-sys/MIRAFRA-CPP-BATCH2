#include<iostream>
#include<memory>
using namespace std;
void altResource(unique_ptr<int> *p)
{
    *p=make_unique<int>(200);
    cout<<"Resource got change\n";
    cout<<"value in double pointer *p="<<(*p).get()<<endl;
    cout<<"double pointer p="<<p<<endl;
}
int main()
{
    unique_ptr<int>p=make_unique<int>(100);
    unique_ptr<int>q=move(p); //p moving ownership
    altResource(&q); //passing q address
    if(p==nullptr)
    {
        cout<<"p is nullptr\n";
    }
    cout<<"q="<<q.get()<<endl;
    cout<<"&q="<<&q<<endl;
    return 0;
}
//actual parameter is rvaluehttps://www.onlinegdb.com/online_c++_compiler#tab-stdin
//formal parameter is lvalue
//in standard move, it is reverse














