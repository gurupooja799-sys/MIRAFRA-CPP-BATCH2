#include<iostream>
#include<memory>
using namespace std;
class gpio
{
    unique_ptr<int>pin;
    public:
    gpio(int p):pin(make_unique<int>(p))
    {
        cout<<"gpio constructor\n";
    }
    void show() const
    {
        cout<<"pin="<<*pin<<endl;
    }
};
int main()
{
    gpio g(3);
    g.show();
    return 0;
}