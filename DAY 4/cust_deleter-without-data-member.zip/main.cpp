#include<iostream>
#include<memory>
using namespace std;
class gpio 
{
    int *pin;
    public:
    gpio(int i=-1):pin(new int(i))
    {
        cout<<"constructor of gpio\n";
    }
    ~gpio()
    {
        cout<<"destructor of gpio\n";
    }
    void getpin()
    {
        cout<<"pin="<<*pin<<endl;
    }
};
class gpiodeleter
{
    public:
    gpiodeleter()
    {
        cout<<"constructor of deleter\n";
    }
    void operator()(gpio* ob) const
    {
       
        delete ob;
        cout<<"object deleted\n";
    }
};
int main()
{
    unique_ptr<gpio,gpiodeleter>p(new gpio(3),gpiodeleter{});
    p->getpin();
    return 0;
}



