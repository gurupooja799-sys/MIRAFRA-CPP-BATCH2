#include<iostream>
#include<vector>
using namespace std;
class gpio
{
    int pin;
    public:
    gpio(int p=-1):pin(p)
    {
        cout<<"constructor called\n";
    }
    gpio(const gpio& ob)
    {
        pin=ob.pin;
        cout<<"copy constructor called\n";
    }
    gpio(gpio&& ob) noexcept
    {
        pin=ob.pin;
        ob.pin=-1;
        cout<<"move constructor called\n";
    }
    ~gpio()
    {
        cout<<"destructor called\n";
    }
};

int main()
{
    vector<gpio>v;
    v.push_back(gpio(1));  //by default push_back calls move constructor
    v.push_back(gpio(2));  //during reallocation if it is without no except  ,it will call copy
    return 0;
}









