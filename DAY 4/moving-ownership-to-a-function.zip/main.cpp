#include<iostream>
#include<memory>
using namespace std;
void altResource(unique_ptr<int> &&p)
{
    *p=200;
    cout<<"Resource got change\n";
}
int main()
{
    unique_ptr<int>p=make_unique<int>(100);
    unique_ptr<int>q=move(p); //p moving ownership
    altResource(move(q)); //q is casting as rvalue
    if(p==nullptr)
    {
        cout<<"p is nullptr\n";
    }
    return 0;
}
//actual parameter is rvalue
//formal parameter is lvalue
//in standard move, it is reverse














