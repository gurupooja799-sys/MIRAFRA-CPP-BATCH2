#include<iostream>
#include<memory>
using namespace std;
void altResource(int* p)
{
    *p=200;
    cout<<"Resource got change\n";
}
int main()
{
    unique_ptr<int>p=make_unique<int>(100);
    altResource(p.get());  //here we are not giving ownership to function,just passing the raw poiinter it will directly effect the unique ptr.
    cout<<"*p="<<*p<<endl;
     cout<<"&p="<<&p<<endl;  //address of unique ptr
     cout<<"p="<<p.get();  //unique pointer
    return 0;
}