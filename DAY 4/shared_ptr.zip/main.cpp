#include<iostream>
#include<memory>
using namespace std;
class Sensor
{
    public:
    int t;
    Sensor(int i=0):t(i)
    {
        cout<<"constructor called\n";
    }
    ~Sensor()
    {
        cout<<"destructor called\n";
    }
    int read() const{
        return t;
    }
    
};

void display(shared_ptr<Sensor>s)
{
    cout<<"display="<<s->read()<<endl;
}
void logger(shared_ptr<Sensor>s)
{
    cout<<"logger="<<s->read()<<endl;
}
void control(shared_ptr<Sensor>s)
{
    cout<<"control="<<s->read()<<endl;
}

int main()
{
    shared_ptr<Sensor>s=make_shared<Sensor>(20);
    display(s);
    logger(s);
    control(s);
    return 0;
}







