/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

// Online C++ compiler to run C++ program online
#include <iostream>
#include<unistd.h>
#include<fcntl.h>
using namespace std;
class file
{
    int fd;
    public:
    file(const char * path)
    {
        fd=open(path,O_RDONLY);
        cout<<"file open="<<fd<<endl;
        cout<<path<<endl;
    }
    ~file()
    {
        if(fd>=0)
        close(fd);
        cout<<"file close="<<fd<<endl;
        //cout<<path<<endl;
    }
};
int main() {
   file f("/etc/passwd");
   file f1("/pooja");
   cout<<"working..\n";
    return 0;
}