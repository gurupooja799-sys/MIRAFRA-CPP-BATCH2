/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>
#include<unistd.h>
#include<fcntl.h>
#include<cstring>
using namespace std;
class file
{
    int fd;
    public:
    file()
    {
        cout<<"default constructor\n";
    }
    file(const char * path)
    {
        fd=open(path,O_WRONLY|O_CREAT|O_TRUNC,0644);
        cout<<"file open="<<fd<<endl;
        cout<<path<<endl;
    }
    void writefunc(const char *str)
    {
        if(fd>=0)
        write(fd,str,strlen(str));
    }
    void file_creation(const char *path)
    {
        fd=open(path,O_WRONLY|O_CREAT|O_TRUNC,0644);
        cout<<"file open in member function="<<fd<<endl;
        cout<<path<<endl;
    }
    ~file()
    {
        if(fd>=0)
        close(fd);
        cout<<"file close="<<fd<<endl;
        //cout<<path<<endl;
    }
};
int main()
{
  file f1("file1.txt");
  file f2("file2.txt");
  f1.writefunc("im file1....\n");
  f2.writefunc("im file2...\n");
  file f3;
  f3.file_creation("file3.txt");
  f3.writefunc("im a file created in member function\n");
  cout<<"finished\n";
  return 0;
}


