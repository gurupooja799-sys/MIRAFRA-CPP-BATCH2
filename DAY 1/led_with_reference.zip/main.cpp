// Online C++ compiler to run C++ program online
#include <iostream>
using namespace std;
class LED
{
    bool status;
    public:
    void led_off()
    {
        status=0;
    }
    void led_on()
    {
        status=1;
    }
    void toggle()
    {
        status^=1;
    }
   friend void display(const LED &);
};
 void display(const LED &ob)
 {
        if(ob.status)
        cout<<"led on"<<endl;
        else
        cout<<"led off"<<endl;
    }
int main() {
  LED obj;
  obj.led_off();
  display(obj);
  obj.led_on();
  display(obj);
  obj.toggle();
  display(obj);
  return 0;
  
}






