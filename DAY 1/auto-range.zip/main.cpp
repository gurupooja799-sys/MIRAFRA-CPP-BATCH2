#include <iostream>
#include<vector>
using namespace std;
int main() {
  vector<string>vec={"abc","def","ghi","jkl"};
  for(const auto &p:vec)
  cout<<p<<" ";
    return 0;
}