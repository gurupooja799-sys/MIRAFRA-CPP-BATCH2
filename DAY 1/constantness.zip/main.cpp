// Online C++ compiler to run C++ program online
#include <iostream>
using namespace std;
void func(int &b)
{
    b=b*b;
}
void func_const(const int &b,int &n)
{
    cout<<"b is const ref"<<endl;
    n=n*2;
}
int& ref_return(int& c)
{
    c=c*10;
    static int n=50;
    int &r=n;
    return r;
}
int main() {
   const int a=5;
   const int *p;
   p=&a;
   const int &r=a;
   int b=r;
   cout<<"p="<<p<<endl;
   cout<<"a="<<&a<<endl;
   cout<<"r="<<&r<<endl;
   cout<<"b="<<&b<<endl;
   b=7;
   func(b);
   int c=20;
   int n=ref_return(c);
   //r=7;
   cout<<"after change value"<<endl;
   cout<<"a="<<a<<endl;
   cout<<"r="<<r<<endl;
   cout<<"b="<<b<<endl;
   cout<<"c="<<c<<endl;
   cout<<"ref return="<<n<<endl;
   cout<<"&n="<<&n<<endl;
   func_const(b,n);
   cout<<"b="<<b<<endl;
   cout<<"n="<<n<<endl;
    return 0;
}